export interface Record {
  name: string;
  lastName: string;
  email: string;
  phone: string;
}
