import { Component, OnInit, ViewChild } from '@angular/core';
import { MatMenuTrigger, MatMenu } from '@angular/material';

@Component({
  selector: 'app-menu-toggler',
  templateUrl: './menu-toggler.component.html',
  styleUrls: ['./menu-toggler.component.scss']
})
export class MenuTogglerComponent implements OnInit {

  constructor() {}

  ngOnInit() {}
}
