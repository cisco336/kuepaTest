export const DIALOGS = {
  ADD_RECORD: 'add-record',
  NOTIFICATION: 'notification',
  COMFIRM: 'comfirm'
};
